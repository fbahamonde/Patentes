import cv2
import os
import DetectPlates
import base64
import json
from googleapiclient import discovery
from oauth2client.client import GoogleCredentials
import Drawing as dr
import Correction as cor
import consulta
import time
import httplib, urllib

webpage = "http://consultawebvehiculos.carabineros.cl" 
channelID = "279148"
apiKey = "5ZHFPAEAIENLSV5U"
topic = "channels/" + channelID + "/publish/" + apiKey
headers = {"Content-typZZe": "application/x-www-form-urlencoded","Accept": "text/plain"}


###################################################################################################
def main():
    timestr = time.strftime("%Y%m%d-%H%M%S")
    imgOriginalScene  = cv2.imread("ejemplo/kia.jpg")               # open image
    if imgOriginalScene is None:                            # if image was not read successfully
        print "\nError: No se pudo leer la imagen \n\n"      # print error message to std out
        os.system("pause")                                  # pause so user can see error message
        return                                              # and exit program
    listOfPossiblePlates = DetectPlates.detectPlatesInScene(imgOriginalScene)           # detect plates
    if len(listOfPossiblePlates) == 0:                          # if no plates were found
        print "\nno No se detectaron patentes\n"             # inform user no plates were found
    else:                                                       # else
                # if we get in here list of possible plates has at leat one plate

                # sort the list of possible plates in DESCENDING order (most number of chars to least number of chars)
        listOfPossiblePlates.sort(key = lambda possiblePlate: len(possiblePlate.strChars), reverse = True)

                # suppose the plate with the most recognized chars (the first plate in sorted by string length descending order) is the actual plate
        licPlate = listOfPossiblePlates[0]
        recorte=licPlate.imgPlate
        cv2.imwrite("recorte patente/"+timestr+".png", recorte) 
        credentials = GoogleCredentials.get_application_default()
        service = discovery.build('vision', 'v1', credentials=credentials)
        
        with open("recorte patente/"+timestr+".png", 'rb') as image:
            image_content = base64.b64encode(image.read())
            service_request = service.images().annotate(body={
                    'requests': [{
                            'image': {
                                    'content': image_content.decode('UTF-8')
                                    },
                            'features': [{
                                    'type': 'TEXT_DETECTION',
                                    'maxResults': 1    
                                    }]
                            }]
                            })
        response = service_request.execute()
        resultado=json.dumps(response['responses'][0]['fullTextAnnotation']['text'], indent=4, sort_keys=True)
        resultado=cor.remove_punctuation(resultado)
        print resultado
        
        robo=consulta.consulta(resultado,webpage)
        print robo
        if robo=="Auto robado":
            cuentarobo=1;
        else:
            cuentarobo=0;
        dr.drawRedRectangleAroundPlate(imgOriginalScene, licPlate)             # draw red rectangle around plate
        dr.writeLicensePlateCharsOnImage(imgOriginalScene, licPlate,resultado)           # write license plate text on the image
        #cv2.imshow("imgOriginalScene", imgOriginalScene)                # re-show scene image
        cv2.imwrite("captura auto/"+timestr+".png", imgOriginalScene)           # write image out to file
        #cv2.imshow("imgPlate", licPlate.imgPlate)           # show crop of plate and threshold of plate
    #cv2.waitKey(0)					# hold windows open until user presses a key
        params = urllib.urlencode({'field1': str(resultado), 'field2':str(cuentarobo),'key':'5ZHFPAEAIENLSV5U'})
        conn= httplib.HTTPConnection("api.thingspeak.com:80")
        try:
            conn.request("POST", "/update", params, headers)
            response = conn.getresponse()
            response.read()
            conn.close()
        except:
            print "connection failed"
    return

if __name__ == "__main__":
    main()

